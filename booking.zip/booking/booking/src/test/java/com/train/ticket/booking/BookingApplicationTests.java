package com.train.ticket.booking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	public void test() {
		BookingApplication.main(new String[] {});
	}

}
